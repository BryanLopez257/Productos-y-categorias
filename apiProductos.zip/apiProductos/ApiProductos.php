<?php
include 'config.php';
$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        $stmt = $pdo->query("SELECT p.*, c.nombre as cat_nombre FROM productos p JOIN categorias c ON p.categoria_id = c.id");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;
    case 'POST':
        $stmt = $pdo->prepare("INSERT INTO productos (nombre, stock, categoria_id) VALUES (?, ?, ?)");
        $stmt->execute([$_POST['nombre'], $_POST['stock'], $_POST['categoria_id']]);
        break;
    case 'PUT':
        parse_str(file_get_contents("php://input"), $_PUT);
        $stmt = $pdo->prepare("UPDATE productos SET nombre = ?, stock = ?, categoria_id = ? WHERE id = ?");
        $stmt->execute([$_PUT['nombre'], $_PUT['stock'], $_PUT['categoria_id'], $_PUT['id']]);
        break;
    case 'DELETE':
        $stmt = $pdo->prepare("DELETE FROM productos WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        break;
}