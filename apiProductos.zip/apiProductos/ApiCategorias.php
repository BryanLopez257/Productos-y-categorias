<?php
include 'config.php';
$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        $stmt = $pdo->query("SELECT * FROM categorias");
        $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($res as &$cat) {
            $stP = $pdo->prepare("SELECT * FROM productos WHERE categoria_id = ?");
            $stP->execute([$cat['id']]);
            $cat['productos'] = $stP->fetchAll(PDO::FETCH_ASSOC);
        }
        echo json_encode($res);
        break;
    case 'POST':
        $stmt = $pdo->prepare("INSERT INTO categorias (nombre) VALUES (?)");
        $stmt->execute([$_POST['nombre']]);
        break;
    case 'PUT':
        parse_str(file_get_contents("php://input"), $_PUT);
        $stmt = $pdo->prepare("UPDATE categorias SET nombre = ? WHERE id = ?");
        $stmt->execute([$_PUT['nombre'], $_PUT['id']]);
        break;
    case 'DELETE':
        $stmt = $pdo->prepare("DELETE FROM categorias WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        break;
}