package servlets;

import com.google.gson.JsonArray;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import Controller.ConsumirApiPHP; 
import java.net.URLEncoder;

@WebServlet(name = "SvProductos", urlPatterns = {"/SvProductos"})
public class SvProductos extends HttpServlet {

    
    String url = "http://localhost/apiProductos/ApiProductos.php";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setAttribute("productos", ConsumirApiPHP.get(url));
        request.getRequestDispatcher("/productos.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        String params = "nombre=" + URLEncoder.encode(request.getParameter("nombre"), "UTF-8") +
                        "&stock=" + request.getParameter("stock") +
                        "&categoria_id=" + request.getParameter("cat_id");

        if (id != null && !id.isEmpty()) {
            ConsumirApiPHP.call(url, "PUT", params + "&id=" + id);
        } else {
            ConsumirApiPHP.call(url, "POST", params);
        }
        response.sendRedirect("SvProductos");
    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ConsumirApiPHP.call(url, "DELETE", request.getParameter("id"));
    }


}
