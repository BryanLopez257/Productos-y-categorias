package servlets;

import com.google.gson.JsonArray;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import Controller.ConsumirApiPHP; // <-- IMPORTANTE: Cambiado a tu nueva clase
import java.net.URLEncoder;

@WebServlet(name = "SvCategorias", urlPatterns = {"/SvCategorias"})
public class SvCategorias extends HttpServlet {
String url = "http://localhost/apiProductos/ApiCategorias.php";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Obtenemos el listado de categorías desde la API
        JsonArray categorias = ConsumirApiPHP.get(url);
        request.setAttribute("categorias", categorias);
        request.getRequestDispatcher("/categorias.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String id = request.getParameter("id");
        String nombre = request.getParameter("nombre");
        
        // Codificamos los parámetros para evitar errores con espacios o tildes
        String params = "nombre=" + URLEncoder.encode(nombre, "UTF-8");

        if (id != null && !id.isEmpty()) {
            // Si hay ID, es una actualización (PUT)
            ConsumirApiPHP.call(url, "PUT", params + "&id=" + id);
        } else {
            // Si no hay ID, es una creación (POST)
            ConsumirApiPHP.call(url, "POST", params);
        }
        
        response.sendRedirect("SvCategorias");
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String id = request.getParameter("id");
        // Llamamos a la API con el método DELETE
        ConsumirApiPHP.call(url, "DELETE", id);
    }

}