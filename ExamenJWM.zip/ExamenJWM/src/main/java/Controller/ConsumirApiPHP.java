package Controller;

import com.google.gson.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

public class ConsumirApiPHP {
    private static final HttpClient cliente = HttpClient.newHttpClient();

    public static JsonArray get(String urlApi) {
        try {
            URL url = new URL(urlApi);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            if (conn.getResponseCode() == 200) {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                return JsonParser.parseReader(br).getAsJsonArray();
            }
        } catch (Exception e) { e.printStackTrace(); }
        return new JsonArray();
    }

    public static boolean call(String url, String metodo, String params) {
        try {
            HttpRequest.Builder builder = HttpRequest.newBuilder()
                    .uri(new URI(url))
                    .header("Content-Type", "application/x-www-form-urlencoded");
            
            if (metodo.equals("POST")) builder.POST(HttpRequest.BodyPublishers.ofString(params));
            else if (metodo.equals("PUT")) builder.method("PUT", HttpRequest.BodyPublishers.ofString(params));
            else builder.uri(new URI(url + "?id=" + params)).DELETE();

            return cliente.send(builder.build(), HttpResponse.BodyHandlers.ofString()).statusCode() == 200;
        } catch (Exception e) { return false; }
    }
}