<%@page import="com.google.gson.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <script>
        function borrar(id) {
            if(confirm('¿Seguro?')) {
                fetch('SvProductos?id=' + id, { method: 'DELETE' })
                .then(() => location.reload());
            }
        }
        function editar(id, nom, stock, cat) {
            document.getElementById('id').value = id;
            document.getElementById('nom').value = nom;
            document.getElementById('stk').value = stock;
            document.getElementById('cat').value = cat;
        }
    </script>
</head>
<body>
    <form action="SvProductos" method="POST">
        <input type="hidden" name="id" id="id">
        <input type="text" name="nombre" id="nom" placeholder="Nombre" required>
        <input type="number" name="stock" id="stk" placeholder="Stock" required>
        <input type="number" name="cat_id" id="cat" placeholder="ID Cat" required>
        <button type="submit">Guardar</button>
    </form>
    <table border="1">
        <tr><th>ID</th><th>Nombre</th><th>Stock</th><th>Categoría</th><th>Acciones</th></tr>
        <% JsonArray prods = (JsonArray) request.getAttribute("productos");
           if(prods != null) for(JsonElement e : prods) { JsonObject p = e.getAsJsonObject(); %>
           <tr>
               <td><%= p.get("id").getAsString() %></td>
               <td><%= p.get("nombre").getAsString() %></td>
               <td><%= p.get("stock").getAsString() %></td>
               <td><%= p.get("cat_nombre").getAsString() %></td>
               <td>
                   <button onclick="editar('<%= p.get("id").getAsString() %>', '<%= p.get("nombre").getAsString() %>', '<%= p.get("stock").getAsString() %>', '<%= p.get("categoria_id").getAsString() %>')">Editar</button>
                   <button onclick="borrar('<%= p.get("id").getAsString() %>')">Borrar</button>
               </td>
           </tr>
        <% } %>
    </table>
    <p><a href="SvCategorias">Gestionar Inventario de Categorias</a></p>
</body>
</html>