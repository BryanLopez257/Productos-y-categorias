<%@page import="com.google.gson.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Categorías - Mini Pancakes</title>
    <script>
        // Función para enviar petición DELETE al Servlet
        function borrar(id) {
            if(confirm('¿Estás seguro de eliminar esta categoría? Se borrarán sus productos asociados.')) {
                fetch('SvCategorias?id=' + id, { method: 'DELETE' })
                .then(response => {
                    if(response.ok) location.reload();
                    else alert('Error al eliminar la categoría');
                });
            }
        }

        // Función para cargar los datos en el formulario de edición
        function editar(id, nombre) {
            document.getElementById('id_cat').value = id;
            document.getElementById('nombre_cat').value = nombre;
            document.getElementById('titulo_form').innerText = 'Editar Categoría';
        }
    </script>
</head>
<body>
    <h2 id="titulo_form">Nueva Categoría</h2>
    <form action="SvCategorias" method="POST">
        <input type="hidden" name="id" id="id_cat">
        
        <label>Nombre:</label>
        <input type="text" name="nombre" id="nombre_cat" placeholder="Ej. Dulces, Bebidas..." required>
        
        <button type="submit">Guardar</button>
        <button type="button" onclick="location.reload()">Limpiar / Nuevo</button>
    </form>

    <hr>

    <h2>Listado de Categorías</h2>
    <table border="1" cellpadding="10">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Productos</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <% 
                JsonArray cats = (JsonArray) request.getAttribute("categorias");
                if(cats != null && cats.size() > 0) {
                    for(JsonElement e : cats) { 
                        JsonObject c = e.getAsJsonObject(); 
                        String id = c.get("id").getAsString();
                        String nombre = c.get("nombre").getAsString();
                        JsonArray productos = c.getAsJsonArray("productos");
            %>
            <tr>
                <td><%= id %></td>
                <td><%= nombre %></td>
                <td>
                    <% if(productos.size() > 0) { %>
                        <ul>
                        <% for(JsonElement ep : productos) { %>
                            <li><%= ep.getAsJsonObject().get("nombre").getAsString() %></li>
                        <% } %>
                        </ul>
                    <% } else { %>
                        <small>Sin productos</small>
                    <% } %>
                </td>
                <td>
                    <button onclick="editar('<%= id %>', '<%= nombre %>')">Editar</button>
                    <button onclick="borrar('<%= id %>')" style="color: red;">Borrar</button>
                </td>
            </tr>
            <% 
                    }
                } else {
            %>
            <tr><td colspan="4">No hay categorías registradas.</td></tr>
            <% } %>
        </tbody>
    </table>

    <p><a href="SvProductos">Gestionar Inventario de Productos</a></p>
</body>
</html>